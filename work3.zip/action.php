<p>Вы ввели:</p><pre>
<?php
print_r($_GET);
?>
</pre>